import spacy
print(spacy.__version__)