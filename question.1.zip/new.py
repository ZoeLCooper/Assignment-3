import tkinter as tk
from functools import wraps

# Decorator to log button clicks
def log_click(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"{func.__name__} button clicked")
        return func(*args, **kwargs)
    return wrapper

# Class representing video information
class Video:
    def __init__(self, title):
        self.title = title
        self.likes = 0
        self.dislikes = 0

    def like(self):
        self.likes += 1

    def dislike(self):
        if self.dislikes > 0:
            self.dislikes -= 1

# Class for managing the application UI
class YouTubeApp:
    def __init__(self, root):
        self.video = Video("Learning OOP in Python")  # Video instance
        self.root = root

        # UI Setup
        self.setup_ui()

    def setup_ui(self):
        self.root.title("YouTube Like App")

        # Title Label
        tk.Label(self.root, text=self.video.title, font=("Arial", 16)).pack(pady=10)

        # Buttons
        tk.Button(self.root, text="Like", command=self.like_video).pack(pady=5)
        tk.Button(self.root, text="Dislike", command=self.dislike_video).pack(pady=5)
        tk.Button(self.root, text="Update Info", command=self.update_info).pack(pady=5)
        tk.Button(self.root, text="Reset", command=self.reset_video).pack(pady=5)
        tk.Button(self.root, text="Quit", command=self.root.quit).pack(pady=5)

        # Message Label
        self.message_label = tk.Label(self.root, text="", font=("Arial", 12))
        self.message_label.pack(pady=10)

    @log_click
    def like_video(self):
        self.video.like()
        self.message_label.config(text=f"Video Liked! Total Likes: {self.video.likes}")

    @log_click
    def dislike_video(self):
        self.video.dislike()
        self.message_label.config(text=f"Video Disliked! Total Dislikes: {self.video.dislikes}")

    @log_click
    def update_info(self):
        info = f"Video: {self.video.title} | Likes: {self.video.likes} | Dislikes: {self.video.dislikes}"
        self.message_label.config(text=info)

    @log_click
    def reset_video(self):
        self.video.likes = 0
        self.video.dislikes = 0
        self.message_label.config(text="Video data reset!")

# Main application execution
if __name__ == "__main__":
    root = tk.Tk()
    app = YouTubeApp(root)
    root.mainloop()
